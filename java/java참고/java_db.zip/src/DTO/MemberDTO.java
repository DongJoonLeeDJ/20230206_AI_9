package DTO;

public class MemberDTO {
	private String id;
	private String pw;
	private String name;
	private String birthdata;
	private String cellphone;
	
	public MemberDTO() {
		super();
	}
	
	public MemberDTO(String id, String pw, String birthdata) {
		super();
		this.id = id;
		this.pw = pw;
		this.birthdata = birthdata;
	}

	public MemberDTO(String id, String pw, String name, String birthdata, String cellphone) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.birthdata = birthdata;
		this.cellphone = cellphone;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthdata() {
		return birthdata;
	}
	public void setBirthdata(String birthdata) {
		this.birthdata = birthdata;
	}
	public String getCellphone() {
		return cellphone;
	}
	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}
	public void showFindMember() {
		System.out.println("ID: "+getId());
		System.out.println("PW: "+getPw());
		System.out.println("�������: "+getBirthdata());
	}
}

package DTO;

public class SmartPhone {
	String model;	//�𵨸�
	String company;	//������
	String color;	//����
	String memory;	//�޸�
	String price;	//����
	
	public SmartPhone() {
		
	}
	
	public SmartPhone(String model,String company,String color,
			String memory,String price) {
		this.model=model;
		this.company=company;
		this.color=color;
		this.memory=memory;
		this.price=price;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getMemory() {
		return memory;
	}

	public void setMemory(String memory) {
		this.memory = memory;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	public void showSmartPhoneInfo() {
		System.out.printf("�𵨸�:%s\n", getModel());
		System.out.printf("������:%s\n", getCompany());
		System.out.printf("����:%s\n", getColor());
		System.out.printf("�޸�:%s\n", getMemory());
		System.out.printf("����:%s\n", getPrice());
	}
	
}

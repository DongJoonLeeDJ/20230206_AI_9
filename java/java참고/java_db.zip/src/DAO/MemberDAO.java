package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import DTO.MemberDTO;

public class MemberDAO {
	private ArrayList<MemberDTO> memberArrayList; 
	private Connection con;
	private Statement st;
	private PreparedStatement pstmt;
	private ResultSet rs;
	Scanner sc = new Scanner(System.in);

	public MemberDAO() {
		memberArrayList=new ArrayList<MemberDTO>();	
		String user = "system";
		String pw = "1234";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url, user, pw);
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// ȸ������
	public void insertMember(String id, String pw, String name, String birthdata, String cellphone) {
		if(duplicateCheck(id)==1) {
			System.out.println("�ߺ��� ���̵��Դϴ�");
			return;
		}
		String SQL = "insert into member1(id,pw,name,birthdata,cellphone)" + "values(?,?,?,?,?)";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, name);
			pstmt.setString(4, birthdata);
			pstmt.setString(5, cellphone);
			pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// ȸ����������
	public void updateMember(String id, String pw) {
		if (login(id, pw)) {
			System.out.println("������ ��й�ȣ�� �Է��ϼ���");
			String updatepw = sc.next();
			System.out.println("������ �̸��� �Է��ϼ���");
			String updatename = sc.next();
			System.out.println("������ ��������� �Է��ϼ���");
			String updatebd = sc.next();
			System.out.println("������ �޴���ȭ�� �Է��ϼ���");
			String updatecp = sc.next();
			String SQL = "update member1 set pw=?, name=?, birthdata=?, cellphone=? " + "where id=?";
			try {
				pstmt = con.prepareStatement(SQL);
				pstmt.setString(1, updatepw);
				pstmt.setString(2, updatename);
				pstmt.setString(3, updatebd);
				pstmt.setString(4, updatecp);
				pstmt.setString(5, id);
				pstmt.executeQuery();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("���̵� �Ǵ� ��й�ȣ�� �߸��Է� �ϼ̽��ϴ�");
		}
	}

	// ȸ��Ż��
	public void deleteMember(String id, String pw) {
		if (login(id, pw)) {
			System.out.println("Ż���Ͻ÷��� 'Ż��' �� �Է��ϼ���");
			String delete = sc.next();
			if (delete.equals("Ż��")) {
				String SQL = "delete from member1 where id=?";
				try {
					pstmt = con.prepareStatement(SQL);
					pstmt.setString(1, id);
					pstmt.executeQuery();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.println("Ż�� �Ϸ�Ǿ����ϴ�");
			} else {
				System.out.println("�߸� �Է��ϼ̽��ϴ�");
			}
		} else {
			System.out.println("���̵� �Ǵ� ��й�ȣ�� �߸��Է� �ϼ̽��ϴ�");
		}
	}

	// �α���
	public boolean login(String id, String pw) {
		boolean result = false;
		String SQL = "select pw from member1 where id=?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getString(1).contentEquals(pw)) {//ù��° ������ ���� Ÿ�Կ� ������� ���Ͽ� ������ ����
					result = true;
				} else {
					result = false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//���̵� ��й�ȣ ã��
	public ArrayList<MemberDTO> idFind(String name, String cellphone) {
		String SQL="select*from member1 where name=? and cellphone=?";
		try {
			pstmt=con.prepareStatement(SQL);
			pstmt.setString(1, name);
			pstmt.setString(2, cellphone);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				String id=rs.getString("id");
				String pw=rs.getString("pw");
				String birthdata=rs.getString("birthdata");	
				System.out.println("-------------------");
				MemberDTO vo = new MemberDTO(id,pw,birthdata);
				vo.showFindMember();
				memberArrayList.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return memberArrayList;
	}

	// �ߺ�üũ
	public int duplicateCheck(String id) {
		int check = -1;
		String SQL = "select*from member1 where id=?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				check = 1;
			} else {
				check = -1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
}

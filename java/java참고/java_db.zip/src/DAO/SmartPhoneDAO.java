package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DTO.SmartPhone;

public class SmartPhoneDAO {
	private ArrayList<SmartPhone> smartArrayList;
	private Connection con;
	private Statement st;
	private PreparedStatement pstmt;
	private ResultSet rs;

	public SmartPhoneDAO() {
		smartArrayList = new ArrayList<SmartPhone>();
		try {
			String user = "system";
			String pw = "1234";
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			try {
				con = DriverManager.getConnection(url, user, pw);
				st = con.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<SmartPhone> Search() { // ��ü��ȸ
		String SQL = "SELECT * FROM smartphone";
		try {
			rs = st.executeQuery(SQL);
			while (rs.next()) {
				String model = rs.getString("model");
				String company = rs.getString("company");
				String color = rs.getString("color");
				String memory = rs.getString("memory");
				String price = rs.getString("price");
				SmartPhone vo = new SmartPhone(model, company, color, memory, price);
				System.out.println("");
				smartArrayList.add(vo);
				vo.showSmartPhoneInfo();// ������ ��ü�� ArrayList�� ���ҷ� �߰�
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return smartArrayList;
	}

	public ArrayList<SmartPhone> SearchLikeModel(String input_model) { // �𵨸� �˻�
		String SQL = "select*from smartphone where model like ?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, "%" + input_model + "%");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String model = rs.getString("model");
				String company = rs.getString("company");
				String color = rs.getString("color");
				String memory = rs.getString("memory");
				String price = rs.getString("price");

				SmartPhone vo = new SmartPhone(model, company, color, memory, price);
				System.out.println("");
				smartArrayList.add(vo);
				vo.showSmartPhoneInfo();// ������ ��ü�� ArrayList�� ���ҷ� �߰�
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return smartArrayList;
	}

	public ArrayList<SmartPhone> SearchLikeCompany(String input_company) { // ������ ��ȸ
		String SQL = "select*from smartphone where company like ?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, "%" + input_company + "%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String model = rs.getString("model");
				String company = rs.getString("company");
				String color = rs.getString("color");
				String memory = rs.getString("memory");
				String price = rs.getString("price");

				SmartPhone vo = new SmartPhone(model, company, color, memory, price);
				System.out.println("");
				smartArrayList.add(vo);
				vo.showSmartPhoneInfo();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return smartArrayList;
	}

	public ArrayList<SmartPhone> SearchLikeColor(String input_color) { // ���� ��ȸ
		String SQL = "select*from smartphone where color like ?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, "%" + input_color + "%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String model = rs.getString("model");
				String company = rs.getString("company");
				String color = rs.getString("color");
				String memory = rs.getString("memory");
				String price = rs.getString("price");

				SmartPhone vo = new SmartPhone(model, company, color, memory, price);
				System.out.println("");
				smartArrayList.add(vo);
				vo.showSmartPhoneInfo();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return smartArrayList;
	}

	public ArrayList<SmartPhone> SearchLikeMemory(String input_memory) { // �޸� ��ȸ
		String SQL = "select*from smartphone where memory like ?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, "%" + input_memory + "%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String model = rs.getString("model");
				String company = rs.getString("company");
				String color = rs.getString("color");
				String memory = rs.getString("memory");
				String price = rs.getString("price");

				SmartPhone vo = new SmartPhone(model, company, color, memory, price);
				System.out.println("");
				smartArrayList.add(vo);
				vo.showSmartPhoneInfo();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return smartArrayList;
	}

	public void InsertSmartPhoneInfo(String model, String company, String color, String memory, String price) {
		String SQL = "insert into smartphone(model,company,color,memory,price)" + "values(?,?,?,?,?)";
		// �߰�
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, model);
			pstmt.setString(2, company);
			pstmt.setString(3, color);
			pstmt.setString(4, memory);
			pstmt.setString(5, price);
			pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateSmartPhoneInfo(String model, String color, String price) {
		String SQL = "update smartphone set price=?" + "where model=? and color=?";
		// ����
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, price);
			pstmt.setString(2, model);
			pstmt.setString(3, color);
			pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteSmartPhoneInfo(String model, String color) {
		String SQL = "delete from smartphone where model=? and color=?";
		// ����
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, model);
			pstmt.setString(2, color);
			pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

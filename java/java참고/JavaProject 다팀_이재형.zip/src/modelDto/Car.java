package modelDto;

public class Car {
	private String car_Name,provider,color,produce_date,
	receiving_date,price,accident,displacement,distance_driven,
	fuel,transmission;
	
	public Car() {
	}
	
	public Car(String car_Name, String provider, String color, String produce_date, String receiving_date, String price,
			String accident, String displacement, String distance_driven, String fuel, String transmission) {
		super();
		this.car_Name = car_Name;
		this.provider = provider;
		this.color = color;
		this.produce_date = produce_date;
		this.receiving_date = receiving_date;
		this.price = price;
		this.accident = accident;
		this.displacement = displacement;
		this.distance_driven = distance_driven;
		this.fuel = fuel;
		this.transmission = transmission;
	}
	
	public String getCar_Name() {return car_Name;}
	public void setCar_Name(String car_Name) {this.car_Name = car_Name;}
	public String getProvider() {return provider;}
	public void setProvider(String provider) {this.provider = provider;}
	public String getColor() {return color;}
	public void setColor(String color) {this.color = color;}
	public String getProduce_date() {return produce_date;}
	public void setProduce_date(String produce_date) {this.produce_date = produce_date;}
	public String getReceiving_date() {return receiving_date;}
	public void setReceiving_date(String receiving_date) {this.receiving_date = receiving_date;}
	public String getPrice() {return price;}
	public void setPrice(String price) {this.price = price;}
	public String getAccident() {return accident;}
	public void setAccident(String accident) {this.accident = accident;}
	public String getDisplacement() {return displacement;}
	public void setDisplacement(String displacement) {this.displacement = displacement;}
	public String getDistance_driven() {return distance_driven;}
	public void setDistance_driven(String distance_driven) {this.distance_driven = distance_driven;}
	public String getFuel() {return fuel;}
	public void setFuel(String fuel) {this.fuel = fuel;}
	public String getTransmission() {return transmission;}
	public void setTransmission(String transmission) {this.transmission = transmission;}
	////////////////////////////////////////////////////////////////////
	public void printCarInfo() {
		System.out.println(String.format("����:%s, ������:%s, ����:%s, ������:%s, �԰���:%s,"
			+ " ����:%s, �������:%s, ��ⷮ:%s, ����Ÿ�:%s, ����:%s, ���ӱ�:%s",
			 getCar_Name(),getProvider(),getColor(),getProduce_date(),getReceiving_date(),
			 getPrice(),getAccident(),getDisplacement(),getDistance_driven(),
			 getFuel(),getTransmission()));
	}
	
	
	
	
}

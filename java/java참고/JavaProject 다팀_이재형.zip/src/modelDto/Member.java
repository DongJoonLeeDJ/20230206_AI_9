package modelDto;

public class Member {
	private String id,pw,mem_name,addr;
	
	public Member() {
	}

	public Member(String id, String pw, String mem_name, String addr) {
		super();
		this.id = id;
		this.pw = pw;
		this.mem_name = mem_name;
		this.addr = addr;
	}

	public String getId() {return id;}
	public void setId(String id) {this.id = id;}
	public String getPw() {return pw;}
	public void setPw(String pw) {this.pw = pw;}
	public String getMem_name() {return mem_name;}
	public void setMem_name(String mem_name) {this.mem_name = mem_name;}
	public String getAddr() {return addr;}
	public void setAddr(String addr) {this.addr = addr;}
	///////////////////////////////////////////////////////////
	public void printMemberInfo() {
		System.out.println(String.format("ID:%s, PW:%s, �̸�:%s, �ּ�:%s",
				getId(),getPw(),getMem_name(),getAddr()));
	}
	
	
	
}

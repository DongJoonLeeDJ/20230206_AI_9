package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.MemberVO;

public class MemberDAO {
	private ArrayList<MemberVO> dtos;
	private Connection con;
	private Statement st;
	private ResultSet rs;
	
	private PreparedStatement pstmt;
	
	public MemberDAO() {
		dtos = new ArrayList<MemberVO>();
		try {
//		String user = "system";
//        String pw = "12345";
//		String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
	        String pw = "mj4660mp";
	        String url = "jdbc:oracle:thin:@58.227.67.34:1521:xe";
	        
		Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url,user,pw);
			st=con.createStatement();
		}catch(Exception e) {
			System.out.println("�����ͺ��̽� ���� ����:"+e.getMessage());
		}	
	}
	
	//�����ȸ
	public ArrayList<MemberVO> getAllMembers() {
		String SQL="SELECT * FROM USEDCAR";
		try {
			rs=st.executeQuery(SQL);
			while(rs.next()) {	
				String company = rs.getString("company");
				String name = rs.getString("name");
				int price = rs.getInt("price");
				int km	=	rs.getInt("km");
				String color = rs.getString("color");
				String engine =rs.getString("engine");
				String accident =rs.getString("accident");
				String buy_date =rs.getString("buy_date");
				MemberVO VO=new MemberVO(company,name,price,km,color,engine,accident,buy_date);
				dtos.add(VO);
				//ArrayList�� ȸ������ �߰�
			}
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("�����ͺ��̽� ���� ����:"+e.getMessage());
		}
		return dtos;
	}
	//������ �߰�
	public ArrayList<MemberVO> setMembers(String COMPANY,String NAME,int PRICE,int KM,String COLOR,String ENGINE,String ACCIDENT,String DATE) {
		String SQL="INSERT INTO USEDCAR VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, COMPANY);
			pstmt.setString(2, NAME);
			pstmt.setInt(3, PRICE);
			pstmt.setInt(4, KM);
			pstmt.setString(5, COLOR);
			pstmt.setString(6, ENGINE);
			pstmt.setString(7, ACCIDENT);
			pstmt.setString(8, DATE);
			pstmt.executeUpdate();
			System.out.println("������ �߰� �Ϸ�");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("�����ͺ��̽� ���� ����:"+e.getMessage());
		}
		return dtos;
		
	}
	//���� ���� ����
	public ArrayList<MemberVO> UpdateCarPrice(String car,int price) {
		String SQL = "UPDATE USEDCAR SET price=? where name=?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setInt(1, price);
			pstmt.setString(2, car);
			pstmt.executeUpdate();
			System.out.println("���ݼ����Ϸ�");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		return dtos;
	}
	
	//���� ����
	public ArrayList<MemberVO> DeleteCar(String car) {
		String SQL = "DELETE FROM USEDCAR where name =?";
		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car);
			pstmt.executeUpdate();
			System.out.println("�����Ϸ�");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		return dtos;
	}
	//a����b������ ���� �˻�
	public ArrayList<MemberVO> BetweenSearchCar(int min,int max) {
		String SQL = "SELECT * FROM USEDCAR WHERE price>="+min+" and price<="+max;
		try {
			pstmt = con.prepareStatement(SQL);
			rs=st.executeQuery(SQL);
			while(rs.next()) {	
				String company = rs.getString("COMPANY");
				String name = rs.getString("NAME");
				int price = rs.getInt("PRICE");
				int km	=	rs.getInt("KM");
				String color = rs.getString("COLOR");
				String engine =rs.getString("ENGINE");
				String accident =rs.getString("ACCIDENT");
				String buy_date =rs.getString("BUY_DATE");
				MemberVO VO=new MemberVO(company,name,price,km,color,engine,accident,buy_date);
				dtos.add(VO);
				pstmt.executeUpdate();
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		return dtos;
	}
	
	//LIKE 
	public ArrayList<MemberVO> SearchCar(String CarName) {
		String SQL = "SELECT * FROM USEDCAR WHERE NAME LIKE '%"+CarName+"%'";
		try {
			pstmt = con.prepareStatement(SQL);
			rs=st.executeQuery(SQL);
			while(rs.next()) {	
				String company = rs.getString("COMPANY");
				String name = rs.getString("NAME");
				int price = rs.getInt("PRICE");
				int km	=	rs.getInt("KM");
				String color = rs.getString("COLOR");
				String engine =rs.getString("ENGINE");
				String accident =rs.getString("ACCIDENT");
				String buy_date =rs.getString("BUY_DATE");
				MemberVO VO=new MemberVO(company,name,price,km,color,engine,accident,buy_date);
				dtos.add(VO);
				pstmt.executeUpdate();
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		return dtos;
	}
}

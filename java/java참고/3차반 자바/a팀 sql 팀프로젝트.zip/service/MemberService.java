package service;

import java.util.ArrayList;
import dao.MemberDAO;
import dto.MemberVO;

public class MemberService {
	
	//dao�� ����
	private MemberDAO dao;
	public MemberService() {
		dao=new MemberDAO();
	}
	
	//��� ��ȸ
	public ArrayList<MemberVO> getAllMembers(){
		return dao.getAllMembers();
	}
	
	//������ �߰� "INSERT INTO USEDCAR VALUES(?, ?, ?, ?, ?, ?, ?, ?, SYSDATE)"
	public ArrayList<MemberVO> setMembers(String COMPANY,String NAME,int PRICE,int KM,String COLOR,String ENGINE,String ACCIDENT,String DATE){
		return dao.setMembers(COMPANY, NAME, PRICE, KM, COLOR, ENGINE, ACCIDENT, DATE);
	}
	
	//���� ���� ���� "UPDATE USEDCAR SET "+car+"="+price+" where NAME = "+car
	public ArrayList<MemberVO> UpdateCarPrice(String car,int price){
		return dao.UpdateCarPrice(car,price);
	}
	
	//���� ���� "DELETE FROM USEDCAR where name = "+car
	public ArrayList<MemberVO> DeleteCar(String car) {
		return dao.DeleteCar(car);
	}
	
	//�������� ���� �˻� "SELACT * FROM USEDCAR WHERE price="+min+" and price="+max;
	public ArrayList<MemberVO> BetweenSearchCar(int min,int max){
		return dao.BetweenSearchCar(min, max);
	}
	
	//�������� �˻�  "SELECT * FROM USEDCAR WHERE NAME LIKE '%"+CarName+"%'";
	public ArrayList<MemberVO> SearchCar(String CarName){
		return dao.SearchCar(CarName);
	}
}

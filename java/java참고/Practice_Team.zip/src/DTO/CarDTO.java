package DTO;

import java.util.Scanner;

public class CarDTO {
	
	Scanner s = new Scanner(System.in);
	
	private String model; // �����̸�
	private String company; // ������
	private String color; // ����
	private String produceDate; // ������
	private String receivingDate; // �԰���
	private String price; // ����
	private String accident; // �������
	private String displacement; // ��ⷮ
	private String transmission;; // Ʈ�����̼�(����,����)
	
	public void showCarDTO() {
		System.out.println("===================");
		System.out.println("��: " + model);
		System.out.println("������: " + company);
		System.out.println("����: " + color);
		System.out.println("������: " + produceDate);
		System.out.println("�԰���: " + receivingDate);
		System.out.println("����: " + price);
		System.out.println("�������: " + accident);
		System.out.println("��ⷮ: " + displacement);
		System.out.println("���ӱ�(����,����): " + transmission);
		System.out.println("===================");
	}
	
	public CarDTO(String model, String company, String color, String produceDate, String receivingDate, String price,
			String accident, String displacement, String transmission) {
		super();
		this.model = model;
		this.company = company;
		this.color = color;
		this.produceDate = produceDate;
		this.receivingDate = receivingDate;
		this.price = price;
		this.accident = accident;
		this.displacement = displacement;
		this.transmission = transmission;
	}

	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getCompany() {
		return company;
	}


	public void setCompany(String company) {
		this.company = company;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public String getProduceDate() {
		return produceDate;
	}


	public void setProduceDate(String produceDate) {
		this.produceDate = produceDate;
	}


	public String getReceivingDate() {
		return receivingDate;
	}


	public void setReceivingDate(String receivingDate) {
		this.receivingDate = receivingDate;
	}


	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}


	public String getAccident() {
		return accident;
	}


	public void setAccident(String accident) {
		this.accident = accident;
	}


	public String getDisplacement() {
		return displacement;
	}


	public void setDisplacement(String displacement) {
		this.displacement = displacement;
	}


	public String getTransmission() {
		return transmission;
	}


	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

}

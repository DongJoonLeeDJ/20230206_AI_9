package Controller;

public class LoginSuccessMenu {

}

package Controller;

public class LoginSuccess {

}

package com.team.car.carDTO;

public class Member {
	private String id; // ������
	private String password; // ��й�ȣ
	private String name; // ȸ���̸�
	private String age; // ȸ������
	private String gender; // ȸ������
	private String address; // ȸ���ּ�
	private String phone; // ȸ�� �޴�����ȣ
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getpassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getgender() {
		return gender;
	}

	public void setgender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getphone() {
		return phone;
	}

	public void setphone(String phone) {
		this.phone = phone;
	}

	public Member(String id, String password, String name, String age, String gender, String address, String phone) {
		super();
		this.id = id;
		this.password = password;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.address = address;
		this.phone = phone;
	}

	public void MemberInfo() {
		System.out.println("�� �� ��:" + id);
		System.out.println("��� ��ȣ:" + password);
		System.out.println("ȸ�� �̸�:" + name);
		System.out.println("ȸ�� ����:" + age);
		System.out.println("ȸ�� ����:" + gender);
		System.out.println("ȸ�� �ּ�:" + address);
		System.out.println("ȸ�� �޴�����ȣ:" + phone);
	}
}

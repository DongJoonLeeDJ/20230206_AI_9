package com.team.car;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import com.team.car.carDAO.CarDAO;
import com.team.car.carDTO.Car;
import com.team.car.carMenu.CarConditions;
import com.team.car.carMenu.CarMenu;
import com.team.car.carMenu.CarUpdateMenu;

public class CarController {

	public void CarMain() throws SQLException {
		CarMenu Cmenu = new CarMenu();
		CarDAO Cdata = new CarDAO();
		CarConditions CarCon = new CarConditions();
		CarUpdateMenu Carup = new CarUpdateMenu();
		ArrayList<Car> carArrayList;
		String carname = "";
		String provider = "";
		String color = "";
		String production = "";
		String receiving = "";
		String price = "";
		String accident = "";
		String displace = "";
		String distan = "";
		String fuel = "";
		String trans = "";
		Scanner s = new Scanner(System.in);
		while (true) { // ���θ޴� �۵�
			switch (Cmenu.menu()) {
			case CarMenu.CAR_MENU_ALL:
				Cdata.CarSearch();
				break;
			case CarMenu.CAR_MENU_CON:
				while (true) {
					int searchMenu = CarCon.Menu();
					if (searchMenu == CarConditions.CAR_CONDITIONS_NAME) {
						Cdata.SearchCarName(carname);

					} else if (searchMenu == CarConditions.CAR_CONDITIONS_PROVIDER) {
						Cdata.SearchProvider(provider);

					} else if (searchMenu == CarConditions.CAR_CONDITIONS_PRODUCTION) {
						Cdata.SearchProduction(production);

					} else if (searchMenu == CarConditions.CAR_CONDITIONS_PRICE) {
						Cdata.SearchPrice(price);

					} else if (searchMenu == CarConditions.CAR_CONDITIONS_COLOR) {
						Cdata.SearchColor(color);

					} else if (searchMenu == CarConditions.CAR_CONDITIONS_ACCIDENT) {
						Cdata.SearchAccident(accident);
					} else if (searchMenu == CarConditions.CAR_CONDITIONS_DISTAN) {
						Cdata.SearchDistan(distan);
					} else if (searchMenu == CarConditions.CAR_CONDITIONS_END) {
						break;
					}
				}
				break;
			case CarMenu.CAR_MENU_ADD:
				Cdata.InsertCarInfo(carname, provider, color, production, receiving, price, accident, displace, distan,
						fuel, trans);
				break;
			case CarMenu.CAR_MENU_EDIT:
				while (true) {
					int searchMenu = Carup.Menu();
					if (searchMenu == CarUpdateMenu.CAR_UPDATE_COLOR) {
						Cdata.UpdateCarInfoColor(color, carname, provider);

					} else if (searchMenu == CarUpdateMenu.CAR_UPDATE_RECEIVING) {
						Cdata.UpdateCarInfoReceiving(receiving, carname, provider);

					} else if (searchMenu == CarUpdateMenu.CAR_UPDATE_PRICE) {
						Cdata.UpdateCarInfoPrice(price, carname, provider);

					} else if (searchMenu == CarUpdateMenu.CAR_UPDATE_ACCIDENT) {
						Cdata.UpdateCarInfoAccident(accident, carname, provider);

					} else if (searchMenu == CarUpdateMenu.CAR_UPDATE_DISTAN) {
						Cdata.UpdateCarInfoDistan(distan, carname, provider);

					} else if (searchMenu == CarUpdateMenu.CAR_UPDATE_END) {
						break;
					}
				}
				break;
			case CarMenu.CAR_MENU_DEL:
				Cdata.DeleteCarInfo(carname, color);
				break;
			case CarMenu.CAR_MENU_EXIT:
				System.out.println("���α׷� ����!");
				System.exit(0); // ���α׷� ���� ����
			default:
				System.out.println(">>>> �ùٸ� �޴��� �Է��ϼ���! <<<<");
				break;
			}
		}
	}
}
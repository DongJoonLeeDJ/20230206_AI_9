package com.team.car;

import java.sql.SQLException;

import com.team.car.carDAO.MemberDAO;
import com.team.car.carMenu.CarConditions;
import com.team.car.carMenu.MainMenu;
import com.team.car.carMenu.MemberUpdateMenu;

public class Main {

	public static void main(String[] args) throws SQLException {
		String id = "";
		String password = "";
		String name = "";
		String age = "";
		String gender = "";
		String address = "";
		String phone = "";
		MainMenu Mmenu = new MainMenu();
		MemberDAO Mdata = new MemberDAO();
		MemberUpdateMenu Upmenu = new MemberUpdateMenu();
		while (true) { // ���θ޴� �۵�
			switch (Mmenu.menu()) {
			case MainMenu.LOG_MENU_lOGIN:
				Mdata.MemberLogin(id, password);
				break;
			case MainMenu.LOG_MENU_SIGNUP:
				Mdata.InsertMemberInfo(id, password, name, age, gender, address, phone);
				break;
			case MainMenu.LOG_MENU_CHECKINFO:
				Mdata.MemberInfoCheck(id, password);
				break;
			case MainMenu.LOG_MENU_EDIT:
				while (true) {
					int searchMenu = Upmenu.Menu();
					if (searchMenu == MemberUpdateMenu.MEM_UPDATE_AGE) {
						Mdata.UpdateMemberInfoAge(age, id, password);
					} else if (searchMenu == MemberUpdateMenu.MEM_UPDATE_ADDRESS) {
						Mdata.UpdateMemberInfoAddress(address, id, password);
					} else if (searchMenu == MemberUpdateMenu.MEM_UPDATE_PHONE) {
						Mdata.UpdateMemberInfoPhone(phone, id, password);
					} else if (searchMenu == MemberUpdateMenu.MEM_UPDATE_END) {
						break;
					}
				}
				break;
			case MainMenu.LOG_MENU_DEL:
				Mdata.DeleteMemberInfo(id, password);
				break;
			case MainMenu.LOG_MENU_END:
				System.out.println("���α׷� ����!");
				System.exit(0); // ���α׷� ���� ����
			default:
				System.out.println(">>>> �ùٸ� �޴��� �Է��ϼ���! <<<<");
				break;
			}
		}
	}
}

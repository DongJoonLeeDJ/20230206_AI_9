package VIEW;

import java.util.Scanner;
import DTO.member;

public class insertMember {
	Scanner sc = new Scanner(System.in);

	public member insertData() {
		System.out.println("-----------------");
		System.out.println("ȸ�� ������ �����մϴ�.");
		System.out.print("�̸� : ");
		String name = sc.nextLine();
		System.out.print("���̵� : ");
		String id = sc.nextLine();
		System.out.print("�н����� : ");
		String password = sc.nextLine();
		System.out.print("�ּ� : ");
		String address = sc.nextLine();
		return new member(name, id, password, address);
	}
}

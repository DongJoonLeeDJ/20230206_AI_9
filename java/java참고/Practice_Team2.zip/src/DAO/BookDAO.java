package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import DTO.book;
import VIEW.SearchBookMenu;
import VIEW.modifyBook;

public class BookDAO {
	private Connection con;
	private Statement st;

	Scanner s = new Scanner(System.in);
	private ArrayList<book> bookList;

	public void addData(book book) {
		bookList.add(book);
	}

	public BookDAO() {
		bookList = new ArrayList<book>();
		try {
			String user = "system";
			String pw = "1234";
			String url= "jdbc:oracle:thin:@localhost:1521:orcl";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			try {
				con=DriverManager.getConnection(url,user,pw);
				st=con.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		bookList.add(new book("������������", "��ȣ��", "����������", "�Ҽ�", 12600));
		bookList.add(new book("��������", "���η�", "�ƹ����ǻ�", "����", 9000));
		bookList.add(new book("�����ŵ���", "�ڿϼ�", "�ٸ�", "����", 7200));
		bookList.add(new book("�׸����θ���ȭ", "�ڽÿ�", "�ƿ��", "����", 10800));
		bookList.add(new book("�����ֽ���", "������", "�����", "����", 4410));
	}

	// �������
	public void bookIsEmpty() {
		System.out.println("å ������ �����ϴ�.");
	}

	public void bookIsNothings() {
		System.out.println("ã���ô� å�� ��ȸ�� �� �����ϴ�.");
	}
	
	public void searchIndex(int i) 
	{
		if(bookList.isEmpty())
			bookIsEmpty();
		else
		{
			System.out.println("No."+(i+1));
			bookList.get(i).viewBook();
		}
	}
	
	//��ü �˻�
	public void allSearchBook()
	{
		if (bookList.isEmpty())
			bookIsEmpty();
		else {
			for (int i = 0; i < bookList.size(); i++) {
				System.out.println("No." + (i + 1));
				bookList.get(i).viewBook();
			}
		}
	}
	

	// �˻����
	public void searchKeywordsString(String searchString, int searchNumber) { // ���� �˻�
		if (bookList.isEmpty())
			bookIsEmpty();
		else {
			boolean isFind = false;
			if (searchNumber == SearchBookMenu.SEARCH_MENU_VIEW_ALL) {
				allSearchBook();
			}

			else if (searchNumber == SearchBookMenu.SEARCH_MENU_TITLE) {
				for (int i = 0; i < bookList.size(); i++) {
					if (bookList.get(i).getTitle().equals(searchString)) {
						if (!isFind)
							isFind = true;
						System.out.println("No." + (i + 1));
						bookList.get(i).viewBook();
					}
				}
			}

			else if (searchNumber == SearchBookMenu.SEARCH_MENU_AUTHOR) {
				for (int i = 0; i < bookList.size(); i++) {
					if (bookList.get(i).getTitle().equals(searchString)) {
						if (!isFind)
							isFind = true;
						System.out.println("No." + (i + 1));
						bookList.get(i).viewBook();
					}
				}
			}

			else if (searchNumber == SearchBookMenu.SEARCH_MENU_PUBLISHER) {
				for (int i = 0; i < bookList.size(); i++) {
					if (bookList.get(i).getTitle().equals(searchString)) {
						if (!isFind)
							isFind = true;
						System.out.println("No." + (i + 1));
						bookList.get(i).viewBook();
					}
				}
			}

			else if (searchNumber == SearchBookMenu.SEARCH_MENU_GENRE) {
				for (int i = 0; i < bookList.size(); i++) {
					if (bookList.get(i).getTitle().equals(searchString)) {
						if (!isFind)
							isFind = true;
						System.out.println("No." + (i + 1));
						bookList.get(i).viewBook();
					}
				}
			} else {
				System.out.println("�߸��� ��ȣ�Դϴ�.");
			}
			if (!isFind)
				bookIsNothings();
		}
	}

	public void searchKeyWordsInt(int searchInteger, int searchNum) {
		if (bookList.isEmpty())
			bookIsEmpty();
		else {
			boolean isFind = false;
			if (searchNum == SearchBookMenu.SEARCH_MENU_PRICE) {
				for (int i = 0; i < bookList.size(); i++) {
					if (bookList.get(i).getPrice() == searchInteger) {
						if (!isFind)
							isFind = true;
						System.out.println("No." + (i + 1));
						bookList.get(i).viewBook();
					}
				}
			} else {
				System.out.println("�߸��� ��ȣ �Դϴ�.");
			}
			if (!isFind)
				bookIsNothings();
		}
	}

	// ����
	public void insertBook(book b) {
		bookList.add(b);
	}

	public void insertBook(String title, String author, String publisher, String genre, int price) {
		bookList.add(new book(title, author, publisher, genre, price));
	}

	// ����(String)
	public void modifyBookString(int modifybookListIndex, int modifyNumber, String inputString) {
		if (bookList.isEmpty())
			bookIsEmpty();
		else {
			if (modifyNumber == modifyBook.MODIFY_BOOK_TITLE)
				bookList.get(modifybookListIndex - 1).setTitle(inputString);
			if (modifyNumber == modifyBook.MODIFY_BOOK_AUTHOR)
				bookList.get(modifybookListIndex - 1).setAuthor(inputString);
			if (modifyNumber == modifyBook.MODIFY_BOOK_PUBLISHER)
				bookList.get(modifybookListIndex - 1).setPublisher(inputString);
			if (modifyNumber == modifyBook.MODIFY_BOOK_GENRE)
				bookList.get(modifybookListIndex - 1).setGenre(inputString);
		}
	}

	// ����(Integer)
	public void modifyBookInt(int modifybookListIndex, int modifyNumber, int inputInt) {
		if (bookList.isEmpty())
			bookIsEmpty();
		else {
			if (modifyNumber == modifyBook.MODIFY_BOOK_PRICE)
				bookList.get(modifybookListIndex - 1).setPrice(inputInt);
		}
	}

	
	//ArrayListSizeCheck
	public int getBookListSize() {
		return bookList.size();
	}
	
	//����
	public void deleteBook(int deleteInputIndex) {
		if(!bookList.isEmpty()) {
			bookList.remove(deleteInputIndex - 1);
			System.out.println("å ������ �����Ǿ����ϴ�!");
		}
		else
		{
			bookIsEmpty();
		}
	}
}

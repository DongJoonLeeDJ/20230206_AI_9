package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
public class DBConnection {
    public static void main(String args[]){
        Connection conn = null;
 
        try{
            //1. ����̹� �ε� : mysql ����̹� �ε�
           Class.forName("com.mysql.jdbc.Driver"); 
            //����̹����� �����⸸ �ϸ� �ڵ� ��ü�� �����ǰ� DriverManager�� ��ϵȴ�.
 
            //2. mysql�� �����Ű��
            String url = "jdbc:mysql://localhost/dev?useSSL=false";
 
            conn = DriverManager.getConnection(url, "dev", "dev");
            System.out.println("Successfully Connection!");
        }
 
        catch(ClassNotFoundException e){
            System.out.println("Failed because of not loading driver");
        }
        catch(SQLException e){
            System.out.println("error : " + e);
        }
 
        finally{
            try{
                if(conn != null && !conn.isClosed()){
                    conn.close();
                }
            }
 
            catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
}
 
package Controller;

import java.util.InputMismatchException;
import java.util.Scanner;
import DAO.BookDAO;
import DTO.book;
import VIEW.SearchBookMenu;
import VIEW.modifyBook;

public class bookController {
	BookDAO dbao = new BookDAO();

	Scanner sc = new Scanner(System.in);
	
	public void bookAllView() {
		dbao.allSearchBook();
	}
	
	public void bookViewObj(int inputIndex)
	{
		dbao.searchIndex(inputIndex - 1);
	}

	// search Book Menu
	public void saerchBook(int searchNumber) {
		if (dbao.getBookListSize() == 0) {
			dbao.bookIsEmpty();
			return;
		}

		// String Search Book
		if (searchNumber == SearchBookMenu.SEARCH_MENU_TITLE) {
			System.out.print("ã���� ������ �Է��ϼ��� : ");
			String searchString = inputString();
			dbao.searchKeywordsString(searchString, searchNumber);
		}

		else if (searchNumber == SearchBookMenu.SEARCH_MENU_AUTHOR) {
			System.out.print("ã���� ������ �Է��ϼ��� : ");
			String searchString = inputString();
			dbao.searchKeywordsString(searchString, searchNumber);
		}

		else if (searchNumber == SearchBookMenu.SEARCH_MENU_PUBLISHER) {
			System.out.print("ã���� ���ǻ縦 �Է��ϼ��� : ");
			String searchString = inputString();
			dbao.searchKeywordsString(searchString, searchNumber);
		} else if (searchNumber == SearchBookMenu.SEARCH_MENU_GENRE) {
			System.out.print("ã���� �帣�� �Է��ϼ��� : ");
			String searchString = inputString();
			dbao.searchKeywordsString(searchString, searchNumber);
		}
		
		//Integer Search Book
		else if (searchNumber == SearchBookMenu.SEARCH_MENU_PRICE) {
			System.out.print("ã�� ������ �Է��ϼ��� : ");
			int searchInteger = inputInteger();
			dbao.searchKeyWordsInt(searchInteger, searchNumber);
		}
		
		else
		{
			
		}
	}

	
	//insert BookList
	public void bookInsert(book b)
	{
		dbao.insertBook(b);
	}
	
	//modify BookList
	public void bookModify(int modifyNumber)
	{
		int modifyBookListIndex = 0;
		
		if(dbao.getBookListSize() == 0)
		{
			dbao.bookIsEmpty();
			return;
		}
		
		if(modifyNumber == modifyBook.MODIFY_BOOK_TITLE)
		{
			bookViewObj(modifyBookListIndex);
			System.out.println("���� ���� : ");
			String modifyString = inputString();
			dbao.modifyBookString(modifyBookListIndex, modifyNumber, modifyString);
		}
		
		else if(modifyNumber == modifyBook.MODIFY_BOOK_AUTHOR)
		{
			bookViewObj(modifyBookListIndex);
			System.out.println("���� ���� : ");
			String modifyString = inputString();
			dbao.modifyBookString(modifyBookListIndex, modifyNumber, modifyString);
		}
		
		else if(modifyNumber == modifyBook.MODIFY_BOOK_PUBLISHER)
		{
			bookViewObj(modifyBookListIndex);
			System.out.println("���ǻ� ���� : ");
			String modifyString = inputString();
			dbao.modifyBookString(modifyBookListIndex, modifyNumber, modifyString);
		}
		
		else if(modifyNumber == modifyBook.MODIFY_BOOK_GENRE)
		{
			bookViewObj(modifyBookListIndex);
			System.out.println("�帣 ���� : ");
			String modifyString = inputString();
			dbao.modifyBookString(modifyBookListIndex, modifyNumber, modifyString);
		}
		
		else if(modifyNumber == modifyBook.MODIFY_BOOK_PRICE)
		{
			bookViewObj(modifyBookListIndex);
			System.out.println("���� ���� : ");
			int modifyInt = inputInteger();
			dbao.modifyBookInt(modifyBookListIndex, modifyNumber, modifyInt);
			
		}
	}
	
	
	//����
	public void bookDelete()
	{
		if(dbao.getBookListSize() == 0)
		{
			dbao.bookIsEmpty();
			return;
		}
		else
		{
			bookAllView();
			int deleteBookListIndex = 0;
			System.out.println("������ å�� ��ȣ�� �Է��ϼ���(1~ "+dbao.getBookListSize()+")) : ");
			
			while(true)
			{
				try
				{
					deleteBookListIndex = sc.nextInt();
					if(deleteBookListIndex>=1 && deleteBookListIndex <=dbao.getBookListSize())
						break;
					else
						System.out.println("�߸��� �Է��Դϴ�. �ٽ� �Է����ּ���");
				}
				catch(InputMismatchException e)
				{
					sc = new Scanner(System.in);
					System.out.println("�߸��� �Է��Դϴ�. �ٽ� �Է����ּ���");
				}
			}
			dbao.deleteBook(deleteBookListIndex);
		}
	}
	
	//��������
	public void bookPrev() 
	{
		System.out.println("�������� ���ư��ϴ�.");
	}
	
	public String inputString() {
		return sc.nextLine();
	}

	public int inputInteger() {
		int inputInteger = 0;

		while (true) {
			try {
				inputInteger = sc.nextInt();
				sc.nextLine();
				break;
			} catch (InputMismatchException e) {
				sc = new Scanner(System.in);
				System.out.println("�߸��� �Է��Դϴ�. �ٽ� �Է����ּ���");
			}
		}
		return inputInteger;
	}
}

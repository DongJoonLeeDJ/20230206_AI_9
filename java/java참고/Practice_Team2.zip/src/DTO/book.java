package DTO;

public class book {
	String title; // ����
	String author; // ����
	String publisher; // ���ǻ�
	String genre; // �о�(�帣)
	int price; // ����

	public book() {
		super();
	}

	public book(String title, String author, String publisher, String genre, int price) {
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		this.genre = genre;
		this.price = price;
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	public void viewBook() {
		System.out.println("���� : "+title);
		System.out.println("���� : "+author+" ����");
		System.out.println("���ǻ� : "+publisher);
		System.out.println("�帣 : "+genre);
		System.out.println("���� : "+price+"��");
	}
}

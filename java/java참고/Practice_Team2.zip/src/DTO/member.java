package DTO;

public class member {
	private String memberShip;
	private String name;
	private String id;
	private String password;
	private String address;
	
	public member() {
		super();
	}
	
	public member(String name, String id,String password,String address)
	{
		super();
		this.memberShip="manager";
		this.name=name;
		this.id=id;
		this.password=password;
		this.address=address;
	}
	
	public member(String memberShip, String name, String id,String password,String address)
	{
		super();
		this.memberShip=memberShip;
		this.name=name;
		this.id=id;
		this.password=password;
		this.address=address;
	}

	public String getMemberShip() {
		return memberShip;
	}

	public void setMemberShip(String memberShip) {
		this.memberShip = memberShip;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String memberId) {
		this.id = memberId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void viewMember() {
		System.out.println("��� : "+memberShip);
		System.out.println("�̸� : "+name);
		System.out.println("���̵� : "+id);
		System.out.println("��й�ȣ : "+password);
		System.out.println("�ּ� : "+address);
		System.out.println("");
	}
}

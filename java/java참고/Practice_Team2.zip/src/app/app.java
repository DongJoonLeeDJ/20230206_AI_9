package app;

import Controller.bookController;
import Controller.memberController;
import VIEW.LoginMenu;
import VIEW.SearchBookMenu;
import VIEW.bookMenu;
import VIEW.deleteBook;
import VIEW.insertBook;
import VIEW.insertMember;
import VIEW.modifyBook;


public class app {
	public static void main(String[] args) {
		LoginMenu aloginMenu = new LoginMenu();
		bookMenu abookMenu = new bookMenu();
		insertBook ainsertBook = new insertBook();
		insertMember ainsertMember = new insertMember();
		SearchBookMenu asearchBookMenu = new SearchBookMenu();
		modifyBook amodifyBook = new modifyBook();
		bookController abookController = new bookController();
		memberController amemberController = new memberController();
		deleteBook adeleteBook = new deleteBook();

		while (true) { // Loop Start
			switch (aloginMenu.menu()) { // Return Login Menu Number (Integer)
			case LoginMenu.LOGIN_MENU_LOGIN:
				
				boolean isMemberEmpty = amemberController.isMemberEmpty(); // Return
				if (isMemberEmpty) { // if ArrayList Empty => Not Run Login
					continue;
				} else // ArrayList not Empty => Do Login
				{
					boolean isLogin = amemberController.doLoginMain(); // isLogin : Login Available(Boolean)
					if (!isLogin) // isLogin == False
						System.exit(0); // Program Exit
					else { // Login Success => Run Car Program
						while (true) { // Car Program Loop
							int bookNum = abookMenu.menu();
							if (bookNum == bookMenu.MAIN_MENU_VIEW_SEARCH) {
								while (true) {
									int searchBook = asearchBookMenu.selectBookMenu();

									if (searchBook == SearchBookMenu.SEARCH_MENU_VIEW_ALL)
										abookController.bookAllView();

									else if (searchBook == SearchBookMenu.SEARCH_MENU_PREV) {
										abookController.bookPrev();
										break;
									} else
										abookController.saerchBook(searchBook);
								}
							}

							// �߰�
							else if (bookNum == bookMenu.MAIN_MENU_INSERT)
								abookController.bookInsert(ainsertBook.insertBookmenu());

							// ����
							else if (bookNum == bookMenu.MAIN_MENU_MODIFY) {
								while (true) {
									int modifyNum = amodifyBook.modifyMenu();
									if (modifyNum == modifyBook.MODIFY_PREV) {
										abookController.bookPrev();
										break;
									} else {
										abookController.bookModify(modifyNum);
									}
								}
							}

							// ����
							else if (bookNum == VIEW.bookMenu.MAIN_MENU_DELETE) {
								while (true) {
									int deleteNum = adeleteBook.deleteMenu();
									if (deleteNum == deleteBook.DELETE_MENU_VIEW_ALL)
										abookController.bookAllView();

									else if (deleteNum == deleteBook.DELETE_MENU_DO)
										abookController.bookDelete();

									else if (deleteNum == deleteBook.DELETE_MENU_PREV) {
										abookController.bookPrev();
										break;

									}
								}
							}

							// ����
							if (bookNum == bookMenu.MAIN_MENU_EXIT) {
								System.out.println("���α׷��� �����մϴ�");
								System.exit(0);
							}
						}
					}
				}
				break;

			case LoginMenu.LOGIN_MENU_REGISTER:
				amemberController.memberInsert(ainsertMember.insertData());
				break;

			case LoginMenu.LOGIN_MENU_MODIFY:
				isMemberEmpty = amemberController.isMemberEmpty();
				if (isMemberEmpty) {
					continue;
				} else {
					amemberController.doLoginModify();
				}
				break;

			case LoginMenu.LOGIN_MENU_DELETE:
				isMemberEmpty = amemberController.isMemberEmpty();
				if (isMemberEmpty) {
					continue;
				} else {
					amemberController.doLoginQuit();
				}
				break;
				
			case LoginMenu.LOGIN_MENU_VIRW:
				isMemberEmpty = amemberController.isMemberEmpty();
				if(isMemberEmpty)
				{
					continue;
				}
				else
				{
					amemberController.allView();
				}
				break;
				

			case LoginMenu.LOGIN_MENU_EXIT:
				System.out.println("���α׷��� �����մϴ�.");
				System.exit(0);
				break;
			}
		}
	}
}

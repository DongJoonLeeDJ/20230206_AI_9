#include <stdio.h>

int main() {

    char command[1024];


    // Construct the command
    snprintf(command, sizeof(command), "espeak.exe -v ko -f temp.txt");

    // Execute the command
    int result = system(command);

    if (result != 0) {
        printf("Error running eSpeak command\n");
    }


    return result;
}
